﻿namespace $safeprojectname$
{
using Sitecore.Data;
public struct Templates
{
}
}
